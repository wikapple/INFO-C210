import java.util.Scanner;

public class IsConsecutiveFour{

    public static boolean isConsecutiveFour(int[][] values){

        int[] horizontalArray = new int[4];
        int[] verticalArray = new int[4];
        int[] diagonalDownArray = new int[4];
        int[] diagonalUpArray = new int[4];

        for(int i = 0; i < values.length; i++){
            
            for(int j = 0; j < values[i].length; j++){


                if(j < values[i].length - 3){
                    for(int k = 0; k < 4; k++){
                        horizontalArray[k] = values[i][j+k];

                        System.out.print("\nHorizontalArray: ");
                    for(int number: horizontalArray){
                        System.out.println(" " + number);
                    }

                    }

                }
                if(i < values.length - 3){
                    for(int k = 0; k < 4; k++){
                        verticalArray[k] = values[i+k][j];
                    }
                    System.out.print("\nVerticalArray: ");
                    for(int number: verticalArray){
                        System.out.println(" " + number);
                    }
                }
                if(i < values.length - 3 && j < values[i].length - 3){
                    for(int k = 0; k < 4; k++){
                        diagonalDownArray[k] = values[i+k][j+k];

                        System.out.print("\nDiagonalDownArray: ");
                    for(int number: diagonalDownArray){
                        System.out.println(" " + number);
                    }
                    } 
                }
                if(i > 3 && j < values[i].length - 3){
                    for(int k = 0; k < 4; k++){
                        diagonalUpArray[k] = values[i-k][j+k];
                    }

                    System.out.print("\nDiagonalUpArray: ");
                    for(int number: diagonalUpArray){
                        System.out.println(" " + number);
                    }
                }
            }
        }
        //stub
        return false;
    }




    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of rows and number of columns: ");
        int rows = in.nextInt();
        int columns = in.nextInt();

        int[][] myArray = new int[rows][columns];

        System.out.println("Enter the elements for a 2D array with " + rows + " rows and " + columns + " columns: ");

        for (int m = 0; m < myArray.length; m++){
            for (int n = 0; n<myArray[m].length; n++){
                myArray[m][n] = in.nextInt();
            }
        }

        boolean consecutive = isConsecutiveFour(myArray);
        System.out.println("Complete");
    }

}