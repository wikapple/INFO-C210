import java.util.Scanner;

public class LocateLargest{

    public static int[] locateLargest(double[][] a){
        int[] indexOfLargest = new int[2];
        double highestDouble = a[0][0];
        indexOfLargest[0] = 0; indexOfLargest[1] = 0;
        
        for (int i = 0; i < a.length; i++){
            for(int j = 0; j < a[i].length; j++){
            
                if(highestDouble < a[i][j]){
                    highestDouble = a[i][j];
                    indexOfLargest[0] = i;
                    indexOfLargest[1] = j;
                }
            }            
        }
        return indexOfLargest;
    }


    public static void main(String[] args){
        Scanner in = new Scanner(System.in);
        System.out.println("Enter the number of rows and columns of the array:");
        int rows = in.nextInt();
        int columns = in.nextInt();
        double[][] myArray = new double[rows][columns];

        System.out.println("Enter the array:");

        for(int a = 0; a < myArray.length; a++){
            for(int b = 0; b < myArray[a].length; b++){
                myArray[a][b] = in.nextDouble();
            }
            System.out.println();
        }

        int[] indexOfHighest = locateLargest(myArray);

        System.out.println("The location of the largest element is at (" + indexOfHighest[0] + ", " + indexOfHighest[1] + ")");
    }


}